## ----child = 'introduction.Rmd'------------------------------------------



## ----child = 'bkg-representation.rmd'------------------------------------

## ------------------------------------------------------------------------
library(bnlearn) 
# help(package='bnlearn')

## ------------------------------------------------------------------------
source('functions.R')

## ------------------------------------------------------------------------
string <- paste('[Burglar][Earthquake][Alarm|Burglar:Earthquake]', 
        '[News|Earthquake][Watson|Alarm]', sep = '') 
bl.alarm <- model2network(string )
plot(bl.alarm)

## ------------------------------------------------------------------------
modified.alarm <- drop.arc(bl.alarm, "Earthquake", "News")
modified.alarm <- reverse.arc(modified.alarm , "Alarm", "Burglar")
modified.alarm <- set.arc(modified.alarm, "Earthquake", "Burglar")
# plot(modified.alarm)

## ---- error = TRUE-------------------------------------------------------
modified.alarm <- set.arc(modified.alarm, "Watson", "Earthquake")

## ---- results = 'hide'---------------------------------------------------
bl.alarm 

## ------------------------------------------------------------------------
plot(bl.alarm, highlight = list(nodes='Alarm'))

## ---- warning=FALSE, message=FALSE---------------------------------------
hlight <- list(nodes = c("Earthquake"), arcs = c("Earthquake", "News"), col = "blue", textCol = "grey")
pp <- graphviz.plot(bl.alarm, highlight = hlight, render = FALSE)
Rgraphviz::renderGraph(pp)

## ---- warning=FALSE, message=FALSE---------------------------------------
graph::nodeRenderInfo(pp) <- list(fill="lightgreen", fontsize=40)
Rgraphviz::renderGraph(pp)  

## ------------------------------------------------------------------------
nbr(bl.alarm, node = 'Alarm')
parents(bl.alarm, node = 'Alarm')
children(bl.alarm, node = 'Alarm')
mb(bl.alarm, node = 'Alarm') 

## ------------------------------------------------------------------------
arcs(bl.alarm)
path(bl.alarm, from = "Burglar", to = "Watson")
path(bl.alarm, from = "Watson", to = "Burglar")

## ---- results='hold'-----------------------------------------------------
dsep(bl.alarm, 'Watson', 'News')
dsep(bl.alarm, 'Watson', 'News', 'Alarm')
plot(cpdag(bl.alarm))

## ------------------------------------------------------------------------
yn <- c("yes","no")
B  <- array(dimnames = list(Burglar = yn), dim = 2, c(0.30,0.70))
E  <- array(dimnames = list(Earthquake = yn), dim = 2, c(0.35,0.65))
A  <- array(dimnames = list(Alarm = yn, Earthquake = yn, 
                            Burglar = yn), dim = c(2, 2, 2),
            c(0.95,0.05,0.90,0.10,0.60,0.40,0.01,0.99)) 
W  <- array(dimnames = list(Watson = yn, Alarm = yn), dim = c(2, 2), c(0.80,0.20,0.40,0.60))
N  <- array(dimnames = list(News = yn, Earthquake = yn), dim = c(2, 2), c(0.60,0.40,0.01,0.99))
cpts <- list(Burglar = B, Earthquake = E, Alarm = A, Watson = W, News = N)
bl.alarm.fit = custom.fit(bl.alarm, cpts)

## ---- fig.show = 'hold'--------------------------------------------------
bl.alarm.fit$Earthquake$prob 
bn.fit.barchart(bl.alarm.fit$Earthquake, main = '')
bn.fit.barchart(bl.alarm.fit$News, main = '')

## ---- error=TRUE---------------------------------------------------------
plot(bl.alarm.fit) # Fails
plot(bn.net(bl.alarm.fit))

## ------------------------------------------------------------------------
string <- paste("[ALG][ANL|ALG][MECH|ALG:VECT]", 
          "[STAT|ALG:ANL][VECT|ALG]" , sep = "")
marks.dag = model2network(string)
plot(marks.dag)

## ------------------------------------------------------------------------
ALG.dist = list(coef = c("(Intercept)" = 50.60), sd = 10.62)
ANL.dist = list(coef = c("(Intercept)" = -3.57, ALG = 0.99), sd = 10.5)
MECH.dist = list(coef = c("(Intercept)" = -12.36, ALG = 0.54, VECT = 0.46), sd = 13.97)
STAT.dist = list(coef = c("(Intercept)" = -11.19, ALG = 0.76, ANL = 0.31), sd = 12.61)
VECT.dist = list(coef = c("(Intercept)" = 12.41, ALG = 0.75), sd = 10.48)
ldist = list(ALG = ALG.dist, ANL = ANL.dist, MECH = MECH.dist,
STAT = STAT.dist, VECT = VECT.dist)
marks.fit = custom.fit(marks.dag, ldist) 
marks.fit[c("MECH", "STAT")]$MECH$coefficients

## ------------------------------------------------------------------------
rats.dag = model2network("[SEX][DRUG|SEX][WL1|DRUG][WL2|WL1:DRUG]")
plot(rats.dag) 

## ------------------------------------------------------------------------
SEX.lv = c("M", "F")
DRUG.lv = c("D1", "D2", "D3")
SEX.prob = array(c(0.5, 0.5), dim = 2, 
                 dimnames = list(SEX = SEX.lv))
DRUG.prob = array(c(0.3333, 0.3333, 0.3333, 
                    0.3333, 0.3333, 0.3333),
dim = c(3, 2), dimnames = 
  list(DRUG = DRUG.lv, SEX = SEX.lv))

## ------------------------------------------------------------------------
WL1.coef = matrix(c(7, 7.50, 14.75), nrow = 1, ncol = 3,
dimnames = list("(Intercept)", NULL))
WL1.dist = list(coef = WL1.coef, sd = c(1.58, 0.447, 3.31))

## ------------------------------------------------------------------------
WL2.coef = matrix(c(1.02, 0.89, -1.68, 1.35, -1.83, 0.82), 
                  nrow = 2, ncol = 3,
dimnames = list(c("(Intercept)", "WL1")))
WL2.dist = list(coef = WL2.coef, sd = c(1.78, 2, 1.37))  

## ------------------------------------------------------------------------
ldist = list(SEX = SEX.prob, DRUG = DRUG.prob, WL1 = WL1.dist, WL2 = WL2.dist)
rats.fit = custom.fit(rats.dag, ldist)
rats.fit$WL2$coefficients 

## ------------------------------------------------------------------------
plot(bl.alarm)

## ------------------------------------------------------------------------
vstructs(bl.alarm)

## ---- eval = FALSE-------------------------------------------------------
## dsep(bn=bl.alarm, x='Burglar', y=, z=)

## ---- echo=TRUE, results="hide", fig.keep = "none", eval = TRUE----------
mb(x=bl.alarm, node='Earthquake')
mbe <- subgraph(bl.alarm, nodes = mb(x=bl.alarm, node='Earthquake'))
plot(mbe)

## ---- echo=TRUE, fig.keep = "none", eval = FALSE-------------------------
## par(mfrow=c(2, 3))
## print_mblankets(bl.alarm)
## par(mfrow=c(1, 1))

## ---- eval = FALSE-------------------------------------------------------
## cpdag.alarm <- cpdag(bl.alarm)
## plot(cpdag.alarm)

## ------------------------------------------------------------------------
library(gRain) 
gr.alarm <- as.grain(bl.alarm.fit)

## ------------------------------------------------------------------------
yn <- c("yes","no")
B  <- cptable(~Burglar, values=c(30,70),levels=yn)
E  <- cptable(~Earthquake, values=c(35,65),levels=yn)
A  <- cptable(~Alarm+Earthquake+Burglar, values=c(95,5,90,10,60,40,1,99),levels=yn)
W  <- cptable(~Watson+Alarm, values=c(80,20,40,60),levels=yn)
N  <- cptable(~News+Earthquake, values=c(60,40,1,99), levels=yn)

## ------------------------------------------------------------------------
cptlist <- compileCPT(list(B, E, A, W, N))
gr.alarm.orig <- grain(cptlist)

## ---- echo=TRUE, eval = FALSE, results = "hide"--------------------------
## plot(gr.alarm.orig)

## ------------------------------------------------------------------------
gr.alarm.orig$cptlist$Earthquake

## ---- echo = TRUE, results = "hide"--------------------------------------
bn <- gr.alarm.orig$cptlist$Burglar['no']
en <- gr.alarm.orig$cptlist$Earthquake['no']
an <- gr.alarm.orig$cptlist$Alarm['no', 'no', 'no']
nn <- gr.alarm.orig$cptlist$News['no', 'no']
wn <- gr.alarm.orig$cptlist$Watson['no', 'no']
bn * en * an * nn * wn 

## ------------------------------------------------------------------------
gr.alarm <- compile(gr.alarm.orig) # Compile first
gr.alarm

## ------------------------------------------------------------------------
querygrain(object=gr.alarm, nodes="Earthquake")
querygrain(object=gr.alarm, nodes="Burglar") 

## ---- eval = FALSE-------------------------------------------------------
## no <- rep("no", 5)
## nodes <- c('Burglar', 'Earthquake', 'Alarm', 'Watson', 'News')
## gr.alarm <- setEvidence(object=gr.alarm, nodes=, states=)
## pEvidence(gr.alarm)

## ------------------------------------------------------------------------
gr.alarm
gr.alarm <- retractEvidence(gr.alarm, nodes)
# gr.alarm

## ------------------------------------------------------------------------
gr.alarm <- setEvidence(object=gr.alarm, nodes="Earthquake", states="yes")

## ------------------------------------------------------------------------
gr.alarm <- retractEvidence(gr.alarm, nodes="Earthquake")
gr.alarm <- setEvidence(object=gr.alarm, nodes="Alarm", states="yes")

## ---- eval = FALSE-------------------------------------------------------
## q.wnb <- querygrain(gr.alarm, type = "joint", nodes = )
## q.wnb


## ----child = 'inference.Rmd'---------------------------------------------

## ----child = 'c01-inference-beam.rmd'------------------------------------



## ----child = 'inference-r.Rmd'-------------------------------------------

## ---- results='hide', echo=FALSE, include=TRUE, error=FALSE, warning=FALSE, message=FALSE----
library(bnlearn)
library(gRain)
library(graph)
# library(ggplot2)
source('functions.R')

## ------------------------------------------------------------------------
asia.fit <- load_asia_fit()

## ---- size = 'tiny'------------------------------------------------------
asia.gr <- as.grain(asia.fit)
asia.gr <- compile(asia.gr) 
asia.gr$rip$cliques

## ---- fig.width=2, fig.height=2------------------------------------------
plot(asia.gr$ug)

## ------------------------------------------------------------------------
asia.gr <- propagate(asia.gr) 
asia.gr$equipot[[1]]

## ---- results ='hold'----------------------------------------------------
asia.gr <- compile(asia.gr)
system.time(replicate(1e2, querygrain(asia.gr, 'dysp')))
not_compiled  <- as.grain(asia.fit)
system.time(replicate(1e2, querygrain(not_compiled, 'dysp')))  

## ---- size = 'tiny'------------------------------------------------------
asia.gr <- as.grain(asia.fit)
asia.gr <- compile(asia.gr) 
asia.gr$rip$cliques

## ---- fig.width=2, fig.height=2------------------------------------------
plot(asia.gr$ug)

## ------------------------------------------------------------------------
yn <- c("yes", "no")
set.seed(0)
s <- sample(yn, 1, prob = asia.fit$smoke$prob)
s

## ------------------------------------------------------------------------
set.seed(0) 
samples.asia <- cpdist(asia.fit, nodes = nodes(asia.fit), 
                       evidence = TRUE, n = 15)
summary(samples.asia)

## ------------------------------------------------------------------------
summary(samples.asia)

## ------------------------------------------------------------------------
t <- table(samples.asia[, c('smoke', 'dysp')])
prop.table(t)

## ------------------------------------------------------------------------
t <- table(samples.asia[, c('smoke', 'asia')])
t

## ---- eval = FALSE-------------------------------------------------------
## prod(dim(table(samples.asia)))

## ------------------------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  
     event = (smoke == "no" & dysp == "yes"), 
     evidence = TRUE, n = 15)
ep			  

## ------------------------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  
     event = (smoke == "no" & dysp == "yes"), 
     evidence = TRUE, n = 15)
ep			  

## ---- results = 'hide'---------------------------------------------------
gr.asia <- as.grain(asia.fit)
q <- querygrain(gr.asia, 
       nodes = c("smoke", "dysp"), type = "joint")
q

## ---- eval = FALSE-------------------------------------------------------
## set.seed(0)
## ep <- cpquery(asia.fit,  )

## ---- results='hold'-----------------------------------------------------
compute_nparticles_abserr <- function(delta, epsilon) {
  log(2 / delta) /  (2 * epsilon ^ 2)
}
mbound <- compute_nparticles_abserr(1e-2, 1e-4)  
mbound2 <- compute_nparticles_abserr(1e-2, 1e-5)
formatC(c(mbound, mbound2))
mbound2 > .Machine$integer.max

## ------------------------------------------------------------------------
gr.asia <- as.grain(asia.fit)
q <- querygrain(gr.asia, 
       nodes = c("asia", "tub"), type = "joint")
tp <- q['yes', 'yes']
tp

## ---- message=FALSE, warning=FALSE, size="tiny"--------------------------
nparticles = seq(from = 5 * 10^3, to = 10^6, by = 5 * 10^4)
prob = matrix(0, nrow = length(nparticles), ncol = 20)
for (i in seq_along(nparticles))
   for (j in 1:20)
      prob[i, j] = cpquery(asia.fit, event 
         = (asia == "yes") & (tub == "yes"),
         evidence = TRUE, method = "ls", n = nparticles[i])

## ---- results='hold'-----------------------------------------------------
large <- cpquery(asia.fit, 
        event = (asia == "yes") & (tub == "yes"), 
        evidence = TRUE, method = "ls", n = 2.6e8 )
(large - tp) 
min(large, tp) / max(large, tp)

## ---- eval = FALSE-------------------------------------------------------
## larger <- cpquery(asia.fit,
##          event = (asia == "yes") & (tub == "yes"),
##          evidence = TRUE, method = "ls", n = 2.6e10 )
## larger

## ------------------------------------------------------------------------
set.seed(0)
samples.asia <- cpdist(asia.fit, 
              nodes = c("smoke", "dysp"), 
              evidence=(asia == "yes"), 
              n=5000)

## ---- eval = FALSE, size = "small"---------------------------------------
## ep <- prop.table(table(samples.asia))
## ep <- ep['no', 'yes']
## gray <- setEvidence(gr.asia, nodes = "asia", states = c("yes"))
## q <- querygrain(gray, nodes = c("smoke", "dysp"), type = "joint")
## tp <- q['no', 'yes']
## abs(ep - tp)

## ---- eval = FALSE-------------------------------------------------------
## nrow(samples.asia) /

## ------------------------------------------------------------------------
set.seed(0)
samples.asia <- cpdist(asia.fit, nodes = nodes(asia.fit),
                       evidence=list(asia = "yes"), 
                       n=5000, method = "lw")

## ---- echo = TRUE, results = "hide"--------------------------------------
w <- attr(samples.asia, 'weights')
summary(w)

## ---- eval = FALSE, echo=TRUE, results="hide", fig.keep = "none"---------
## set.seed(0)
## samples.asia <- cpdist(, nodes = ,
##                        evidence=list(lung = 'yes'),
##                        n=5000, method = "lw")
## w <- attr(samples.asia, 'weights')

## ---- fig.height=2-------------------------------------------------------
mutbn = mutilated(asia.fit, list(lung = "yes"))
plot(bn.net(mutbn))
mutbn$lung$prob 

## ---- eval = TRUE, echo=FALSE, results="hide", fig.keep = "none"---------
set.seed(0)
samples.asia <- cpdist(asia.fit, nodes = c("smoke", "dysp"),
                       evidence=list(lung = 'yes'),
                       n=5000, method = "lw")    
w <- attr(samples.asia, 'weights')

## ---- eval = FALSE-------------------------------------------------------
## prop.table(table(samples.asia$smoke))
## asia.fit$smoke

## ------------------------------------------------------------------------
asia.fit$lung$prob['yes', ]

## ---- eval = FALSE, echo=FALSE, results="hide", fig.keep = "none"--------
## head(samples.asia)
## head(w)

## ---- eval = TRUE, echo=TRUE---------------------------------------------
prop.table(xtabs(w ~ smoke + dysp, 
                 data = cbind(samples.asia, w = w)))

## ---- eval = FALSE, echo=TRUE, results="hide", fig.keep = "none"---------
## set.seed(0)
## epl <- cpquery(,  event = (smoke == "no" & dysp == ),
##               evidence = list(lung = 'yes'), n = 5000, method = 'lw')
## epl

## ---- eval = TRUE, echo=FALSE, results="hide", fig.keep = "none"---------
set.seed(0)
epl <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = list(lung = 'yes'), n = 5000, method = 'lw')
epl 

## ---- eval = FALSE, results = 'hide'-------------------------------------
## tpl <- q['no', 'yes']
## abs(tpl - )

## ---- eval = FALSE-------------------------------------------------------
## asia.m <- mutilated(asia.fit, list(dysp = "yes"))
## plot(asia.m)
## bn.net(asia.fit)

## ---- eval = TRUE--------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = list(asia = 'yes'), n = 100, method = 'lw')  
abs(ep - tp)
abs(tp / ep)

## ---- eval = TRUE, echo=TRUE, results="hide", fig.keep = "none"----------
gr.asia <- as.grain(asia.fit)
q <- querygrain(gr.asia, nodes = c("smoke", "lung"), type = "joint")
psl <- q['yes', 'yes'] / (q['yes', 'yes'] + q['yes', 'no'])
sum(w / psl)

## ------------------------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = list(lung = 'yes'), n = 5000, method = 'lw')
abs(ep  - tpl)

## ------------------------------------------------------------------------
head(marks)

## ---- fig.height=2, fig.width=2------------------------------------------
bn.marks <- hc(marks)
plot(bn.marks)

## ---- results = 'hold'---------------------------------------------------
bn.marks.fit <- bn.fit(bn.marks, marks) 
cpquery(bn.marks.fit, event = ((ALG > 60)), evidence = TRUE)      
cpquery(bn.marks.fit, event = ((STAT > 60) & (MECH > 60)), 
        evidence = TRUE)      
cpquery(bn.marks.fit, event = ((STAT > 60) & (MECH > 60)), 
        evidence = (ALG > 60))      

## ------------------------------------------------------------------------
samples.marks <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), 
                        evidence = TRUE)      
cor(samples.marks$STAT, samples.marks$MECH)
samples.marks <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), 
                        evidence = (ALG > 60))
cor(samples.marks$STAT, samples.marks$MECH)   

## ---- echo = TRUE--------------------------------------------------------
cpquery(bn.marks.fit, event = ((STAT > 60)), 
        evidence = ((MECH > 60) & ALG > 60))      
cpquery(bn.marks.fit, event = ((STAT > 60)), 
        evidence = (ALG > 60))

## ------------------------------------------------------------------------
samples.marks <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), evidence = (ALG > 60))      
samples.marks.noevidence <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), evidence = TRUE)      
nrow(samples.marks )
nrow(samples.marks.noevidence) 

## ---- error = TRUE-------------------------------------------------------
cpquery(bn.marks.fit, event = ((STAT > 60)), 
        evidence = list(ALG = c(60, 100)), method = "lw") 
cpquery(bn.marks.fit, event = ((STAT > 60)), 
        evidence = list(ALG = c(60)), method = "lw") 



## ----child = 'learning.Rmd'----------------------------------------------

## ------------------------------------------------------------------------
library(bnlearn)
breast <- foreign::read.arff('data/dbreast-cancer.arff')
head(breast[, 1:5])

## ------------------------------------------------------------------------
anyNA(breast)

## ---- fig.height=2-------------------------------------------------------
hc.breast <- hc(breast, score = "bic")
plot(hc.breast)

## ------------------------------------------------------------------------
score(hc.breast, breast, type="loglik")

## ---- results='hide'-----------------------------------------------------
score(hc.breast, breast, type="bic", debug = TRUE)

## ---- echo = TRUE, results = FALSE---------------------------------------
rev.hc.breast <- reverse.arc(hc.breast, from='age', 'menopause')
score(rev.hc.breast, breast, type="bic")
score(rev.hc.breast, breast, type="k2")

## ---- eval = FALSE-------------------------------------------------------
## loglik.hc.breast <- hc(breast, score='loglik')
## nparams(loglik.hc.breast, breast)

## ---- results = 'hide'---------------------------------------------------
hc.breast 

## ---- eval = FALSE-------------------------------------------------------
## compare(hc.breast, aic.hc.breast, arcs = TRUE)
## graphviz.compare(hc.breast, aic.hc.breast)

## ------------------------------------------------------------------------
set.seed(100)
hc.breast.restart <- hc(breast, restart = 1000, perturb = 10)
BIC(hc.breast.restart, breast)
all.equal(cpdag(hc.breast.restart), cpdag(hc.breast))

## ------------------------------------------------------------------------
gs.breast <- gs(x = breast)

## ---- eval = FALSE-------------------------------------------------------
## score(gs.breast, breast, type = "loglik")

## ------------------------------------------------------------------------
gs.breast <- cextend(gs.breast)
score(gs.breast, breast)

## ---- fig.show='hold'----------------------------------------------------
graphviz.compare(cpdag(hc.breast), cpdag(gs.breast))

## ------------------------------------------------------------------------
shd(gs.breast, hc.breast)

## ---- results = 'hide'---------------------------------------------------
gs.breast

## ---- eval = FALSE-------------------------------------------------------
## gs.breast.string <- gs(breast, alpha=)
## narcs(gs.breast.string)

## ---- eval = FALSE-------------------------------------------------------
## gs.breast.2 <- gs(breast, test = )
## gs.breast.2 <- cextend(gs.breast.2)
## plot(gs.breast.2)

## ---- eval = FALSE, echo=FALSE, results="hide", fig.keep = "none"--------
## gs.breast.2 <- gs(breast, test = 'mi-sh')
## gs.breast.2 <- cextend(gs.breast.2)
## plot(gs.breast.2)

## ---- results = 'hide'---------------------------------------------------
gr.breast <- gs(breast, debug = TRUE)

## ---- results = 'hold'---------------------------------------------------
library(parallel)
cl <- makeCluster(5)
system.time(gs.breast <- gs(breast, cluster = cl))
system.time(gs.breast <- gs(breast))
stopCluster(cl)

## ---- results = 'hide', error=FALSE, warning=FALSE, message=FALSE--------
bn.cv(breast, 'iamb', loss = "logl")
bn.cv(breast, 'hc', loss = "logl")

## ------------------------------------------------------------------------
data("clgaussian.test")
head(clgaussian.test)  

## ------------------------------------------------------------------------
plot(hc(clgaussian.test))

## ------------------------------------------------------------------------
plot(gs(clgaussian.test))

## ---- echo = FALSE, purl = TRUE, out.width='4cm', fig.show='hold'--------
data("marks")
latent <- factor(c(rep("A", 44), "B", rep("A", 7), rep("B", 36)))
plot(hc(marks[latent == "A", ]))
plot(hc(marks[latent == "B", ]))
plot(hc(marks))

## ------------------------------------------------------------------------
lmarks <- data.frame(marks, LAT = latent)
plot(hc(lmarks))

## ------------------------------------------------------------------------
dmarks = discretize(marks, breaks = 2, method = "interval")
plot(hc(data.frame(dmarks, LAT = latent)))

## ------------------------------------------------------------------------
breast.bn.fit <- bn.fit(hc.breast, breast)
bn.fit.barchart(breast.bn.fit$tumor_size) 

## ------------------------------------------------------------------------
breast.bn.fit$menopause$prob[ ,1:3] 

## ------------------------------------------------------------------------
breast.bpe <- bn.fit(hc.breast, breast, method = "bayes", iss = 1)
breast.bpe$menopause$prob[ ,1:3] 

## ---- results = 'hide'---------------------------------------------------
logLik(breast.bn.fit, breast)
logLik(breast.bpe , breast)

## ------------------------------------------------------------------------
data(marks)
bn.marks <- hc(marks)
bn.marks <- bn.fit(bn.marks, marks)
coef(bn.marks)$ALG

## ------------------------------------------------------------------------
bn.marks.reg <- bn.marks
m <- as.matrix(marks)
# You will need the glmnet package for this
library(glmnet)
gnet <- glmnet(m[ , c('VECT', 'MECH')], m[, 'ALG'], alpha =0, family = "gaussian")
coefs <- coef(gnet, s = 0.1)[, 1]
bn.marks.reg$ALG = list(coef = coefs, sd = sigma(bn.marks$ALG)) 
# cpquery(bn.marks.reg, event = ALG > 50, evidence = TRUE)   
bn.marks.reg$ALG$coefficients
bn.marks$ALG $coefficients

## ------------------------------------------------------------------------
load('data/car.rda')
summary(car)

## ------------------------------------------------------------------------
library(bnclassify)

## ---- eval = FALSE-------------------------------------------------------
## nb.car <- nb(class = 'class', dataset =  )

## ------------------------------------------------------------------------
nb.car <- lp(nb.car, car, smooth = 0) 
params(nb.car)[['class']]

## ------------------------------------------------------------------------
car[1, -7]

## ---- eval = FALSE-------------------------------------------------------
## b <- params(nb.car)[['buying']]['vhigh', ]
## m <- params(nb.car)[['maint']]['vhigh', ]
## d <- params(nb.car)[['doors']]['2', ]
## p <- params(nb.car)[['persons']]['2', ]
## l <- params(nb.car)[['lug_boot']]['', ]
## s <- params(nb.car)[['safety']]['', ]
## cp <- params(nb.car)[['class']]
## cpost <- cp * b * m *  * p *  *

## ---- eval = FALSE-------------------------------------------------------
## nb.car <-

## ------------------------------------------------------------------------
p <- predict(nb.car, car, prob = TRUE)
tail(p)

## ---- results = 'hide'---------------------------------------------------
p <- predict(nb.car, car)
tail(p)

## ------------------------------------------------------------------------
cm <- table(predicted=p, true=car$class)
cm
sum(cm * diag(1, nrow(cm), ncol(cm))) / sum(cm)

## ------------------------------------------------------------------------
bnclassify:::accuracy(p, car$class)

## ---- eval = FALSE-------------------------------------------------------
## ci.test(...)

## ---- results = 'hide'---------------------------------------------------
car_wo_doors <- car[, -3]
nb.car.wod <- bnc('nb', 'class', dataset = car, smooth = 1)
p <- predict(nb.car.wod, car )
p <- predict(nb.car, car )
bnclassify::accuracy(p, car$class) 

## ---- eval = FALSE-------------------------------------------------------
## ci.test('maint', 'buying', 'class', car)

## ---- eval = FALSE-------------------------------------------------------
## car2 <- cbind(car, safety2=car$safety)
## nb.car2 <- bnc('nb', 'class', car2, smooth = 1)
## p <- predict(nb.car2, car2)
## bnclassify:::accuracy(p, car2$class)

## ---- eval = FALSE-------------------------------------------------------
## sft <- car[, rep(6,10)]
## colnames(sft) <- paste0('safety', 1:10)
## car2 <- cbind(car, sft)
## nb.car2 <- bnc('nb', 'class', car2, smooth = 1)
## p <- predict(nb.car2, car2)
## bnclassify:::accuracy(p, car2$class)

## ------------------------------------------------------------------------
tn <- tan_cl('class', car)
tn <- lp(tn, car, smooth = 1)
plot(tn)

## ------------------------------------------------------------------------
tns <- tan_cl('class', car, root = 'safety')
plot(tns)

## ------------------------------------------------------------------------
tns <- lp(tns, car, smooth = 1)
p <- predict(tn, car, prob = TRUE)
ps <- predict(tns, car, prob = TRUE)
identical(p, ps)

## ---- results = 'hide'---------------------------------------------------
p <- predict(tn, car )
bnclassify::accuracy(p, car$class) 

## ---- eval = FALSE-------------------------------------------------------
## nparams(...)
## nparams(...)
## logLik(, car)
## logLik(, car)

## ------------------------------------------------------------------------
p <- predict(tn, car )
n <- predict(nb.car, car )
ind_error <- which(p != car$class & n != car$class)
car$class[ind_error]
p[ind_error]
n[ind_error]
p <- predict(tn, car, prob = TRUE )
n <- predict(nb.car, car, prob = TRUE )
# head(p[ind_error, ])
# head(n[ind_error, ])
maxp <- apply(p[ind_error, ], 1, max)
maxn <- apply(n[ind_error, ], 1, max)
plot(maxn, maxp, ylim  = c(0, 1), xlim = c(0, 1))

## ------------------------------------------------------------------------
tn.aic <- tan_cl('class', car, score = 'aic')
tn.aic <- lp(tn.aic, car, smooth = 1)
plot(tn.aic)

## ------------------------------------------------------------------------
AIC(object = tn, car)
AIC(object = tn.aic, car)

## ---- eval = FALSE-------------------------------------------------------
## sl.cmi <- bnclassify:::cmi(, , car, 'class')
## # The number of parameters added is:
## ap <- (3 - 1) * (3 - 1) * 4
## N <-
## N * sl.cmi - ap

## ---- results="hide"-----------------------------------------------------
bnclassify:::local_ode_score_contrib('safety', 
                   'lug_boot', 'class', car)

## ------------------------------------------------------------------------
tn.bic <- tan_cl('class', car, score = 'bic')
plot(tn.bic)

## ---- eval = FALSE, results = "hide"-------------------------------------
## tn.bic <- ...
## bnclassify::cv(list(nb.car, tn, tn.aic, tn.bic),
##                car, k = 10)

## ------------------------------------------------------------------------
set.seed(0)
tn.hc <- tan_hc('class', car, k = 10, epsilon = 0, smooth = 1)

## ------------------------------------------------------------------------
tn.hc$.greedy_scores_log

## ---- eval = FALSE-------------------------------------------------------
## set.seed(0)
## tn.hc2 <- tan_hc('class', car, k = 10, epsilon = , smooth = 1)

## ------------------------------------------------------------------------
tn.hc2$.greedy_scores_log

## ------------------------------------------------------------------------
 system.time(tan_hc('class', car, k = 10, epsilon = 0, smooth = 1))
 system.time(tan_cl('class', car))

## ---- cache = FALSE------------------------------------------------------
set.seed(0)
bs.car <- bsej('class', car, k = 10, epsilon = 0, smooth = 1)

## ---- results = "hide"---------------------------------------------------
bnclassify:::is_supernode(c('maint', 'buying'), bs.car)

## ---- eval = FALSE-------------------------------------------------------
## set.seed(0)
## fs.car <- fssj()

## ------------------------------------------------------------------------
ia.car <- iamb(car)
plot(ia.car)

## ------------------------------------------------------------------------
mb.class <- mb(ia.car, 'class')
mb.car <- bnlearn::subgraph(ia.car, c(mb.class, 'class'))
mb.car <- bn.fit(mb.car, car[, nodes(mb.car)])
mb.grain <- as.grain(mb.car)

## ------------------------------------------------------------------------
p <- gRain::predict.grain(mb.grain,  'class', newdata  = car)
fp <- factor(p$pred$class, levels = levels(car$class))
bnclassify:::accuracy(fp, car$class)


## ----child = 'conclusion.Rmd'--------------------------------------------

## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ---- eval = FALSE-------------------------------------------------------
## load(url("http://www.bnlearn.com/bnrepository/sachs/sachs.rda"))


## ----child = 'hands-on.rmd'----------------------------------------------

## ---- echo = FALSE-------------------------------------------------------
source('funs-slides.R')
setup_knitr() 

## ------------------------------------------------------------------------
sachs = read.table("data/sachs.data.txt", header = TRUE)
head(sachs, n = 5)

## ------------------------------------------------------------------------
library(bnlearn)
sachs.modelstring =
paste("[PKC][PKA|PKC][Raf|PKC:PKA][Mek|PKC:PKA:Raf][Erk|Mek:PKA]",
"[Akt|Erk:PKA][P38|PKC:PKA][Jnk|PKC:PKA][Plcg][PIP3|Plcg]",
"[PIP2|Plcg:PIP3]", sep = "")
dag.sachs = model2network(sachs.modelstring)

## ---- fig.height=2, fig.width=2------------------------------------------
load('data/alarm.rda')
alarm.fit <- bn
bn <- as.bn(as.grain(alarm.fit)) 
plot(as.grain(alarm.fit))


