## ----child = 'c01-reason-representation.rmd'-----------------------------

## ------------------------------------------------------------------------
library(bnlearn) 
?bnlearn

## ------------------------------------------------------------------------
bl.alarm <- model2network('[Burglar][Earthquake][Alarm|Burglar:Earthquake][News|Earthquake][Watson|Alarm]')
plot(bl.alarm) 

## ------------------------------------------------------------------------
modified.alarm <- drop.arc(bl.alarm, "Earthquake", "News")
modified.alarm <- reverse.arc(modified.alarm , "Alarm", "Burglar")
modified.alarm <- set.arc(modified.alarm, "Earthquake", "Burglar")
plot(modified.alarm)

## ---- error = TRUE-------------------------------------------------------
modified.alarm <- set.arc(modified.alarm, "Watson", "Earthquake")

## ------------------------------------------------------------------------
bl.alarm 

## ------------------------------------------------------------------------
nbr(bl.alarm, node = 'Alarm')
parents(bl.alarm, node = 'Alarm')
children(bl.alarm, node = 'Alarm')
mb(bl.alarm, node = 'Alarm') 

## ------------------------------------------------------------------------
plot(bl.alarm, highlight = list(nodes='Alarm'))

## ---- warning=FALSE, message=FALSE---------------------------------------
hlight <- list(nodes = c("Earthquake"), arcs = c("Earthquake", "News"), col = "blue", textCol = "grey")
pp <- graphviz.plot(bl.alarm, highlight = hlight)
Rgraphviz::renderGraph(pp)

## ------------------------------------------------------------------------
arcs(bl.alarm)
path(bl.alarm, from = "Burglar", to = "Watson")
path(bl.alarm, from = "Watson", to = "Burglar")

## ------------------------------------------------------------------------
dsep(bl.alarm, 'Watson', 'News')
dsep(bl.alarm, 'Watson', 'News', 'Alarm')
plot(cpdag(bl.alarm))

## ------------------------------------------------------------------------
yn <- c("yes","no")
B  <- array(dimnames = list(Burglar = yn), dim = 2, c(0.30,0.70))
E  <- array(dimnames = list(Earthquake = yn), dim = 2, c(0.35,0.65))
A  <- array(dimnames = list(Alarm = yn, Earthquake = yn, Burglar = yn), dim = c(2, 2, 2),
            c(0.95,0.05,0.90,0.10,0.60,0.40,0.01,0.99)) 
W  <- array(dimnames = list(Watson = yn, Alarm = yn), dim = c(2, 2), c(0.80,0.20,0.40,0.60))
N  <- array(dimnames = list(News = yn, Earthquake = yn), dim = c(2, 2), c(0.60,0.40,0.01,0.99))
cpts <- list(Burglar = B, Earthquake = E, Alarm = A, Watson = W, News = N)
bl.alarm.fit = custom.fit(bl.alarm, cpts)

## ------------------------------------------------------------------------
bl.alarm.fit$Earthquake 
bn.fit.barchart(bl.alarm.fit$Earthquake)
bn.fit.barchart(bl.alarm.fit$News)

## ------------------------------------------------------------------------
load(url("http://www.bnlearn.com/bnrepository/sachs/sachs.rda"))
sachs.fit <- bn; rm(bn)  

## ---- error=TRUE---------------------------------------------------------
plot(sachs.fit)
plot(bn.net(sachs.fit))
bn.net(sachs.fit) 

## ------------------------------------------------------------------------
marks.dag = model2network("[ALG][ANL|ALG][MECH|ALG:VECT][STAT|ALG:ANL][VECT|ALG]")
plot(marks.dag)

## ------------------------------------------------------------------------
ALG.dist = list(coef = c("(Intercept)" = 50.60), sd = 10.62)
ANL.dist = list(coef = c("(Intercept)" = -3.57, ALG = 0.99), sd = 10.5)
MECH.dist = list(coef = c("(Intercept)" = -12.36, ALG = 0.54, VECT = 0.46), sd = 13.97)
STAT.dist = list(coef = c("(Intercept)" = -11.19, ALG = 0.76, ANL = 0.31), sd = 12.61)
VECT.dist = list(coef = c("(Intercept)" = 12.41, ALG = 0.75), sd = 10.48)
ldist = list(ALG = ALG.dist, ANL = ANL.dist, MECH = MECH.dist,
STAT = STAT.dist, VECT = VECT.dist)
marks.fit = custom.fit(marks.dag, ldist) 

## ------------------------------------------------------------------------
marks.fit[c("MECH", "STAT")] 

## ------------------------------------------------------------------------
rats.dag = model2network("[SEX][DRUG|SEX][WL1|DRUG][WL2|WL1:DRUG]")
plot(rats.dag) 

## ------------------------------------------------------------------------
SEX.lv = c("M", "F")
DRUG.lv = c("D1", "D2", "D3")
SEX.prob = array(c(0.5, 0.5), dim = 2, dimnames = list(SEX = SEX.lv))
DRUG.prob = array(c(0.3333, 0.3333, 0.3333, 0.3333, 0.3333, 0.3333),
dim = c(3, 2), dimnames = list(DRUG = DRUG.lv, SEX = SEX.lv))
WL1.coef = matrix(c(7, 7.50, 14.75), nrow = 1, ncol = 3,
dimnames = list("(Intercept)", NULL))
WL1.dist = list(coef = WL1.coef, sd = c(1.58, 0.447, 3.31))
WL2.coef = matrix(c(1.02, 0.89, -1.68, 1.35, -1.83, 0.82), nrow = 2, ncol = 3,
dimnames = list(c("(Intercept)", "WL1")))
WL2.dist = list(coef = WL2.coef, sd = c(1.78, 2, 1.37))
ldist = list(SEX = SEX.prob, DRUG = DRUG.prob, WL1 = WL1.dist, WL2 = WL2.dist)
rats.fit = custom.fit(rats.dag, ldist)

## ------------------------------------------------------------------------
rats.fit$WL2

## ---- echo = FALSE, message = FALSE--------------------------------------
d <- gRbase::dag(~Burglar, ~Earthquake, ~Alarm:Earthquake:Burglar, ~Watson:Alarm, ~News:Earthquake)
graph::plot(d)
# How to unload a package that is not attached?
# detach('package:gRbase', unload = TRUE)

## ------------------------------------------------------------------------
source('functions.R')

## ------------------------------------------------------------------------
vstructs(bl.alarm)

## ---- eval = FALSE-------------------------------------------------------
## dsep(bn=bl.alarm, x='Burglar', y=, z=)

## ---- echo = FALSE, result = "hide"--------------------------------------
dsep(bn=bl.alarm, x='Burglar', 'Watson', 'Alarm')
#dsep(bn=bl.alarm, x='Burglar', 'News', 'Alarm')

## ---- echo=TRUE, results="hide", fig.keep = "none", eval = TRUE----------
mb(x=bl.alarm, node='Earthquake')
mbe <- subgraph(bl.alarm, nodes = mb(x=bl.alarm, node='Earthquake'))
plot(mbe)

## ---- echo=TRUE, fig.keep = "none", eval = TRUE--------------------------
par(mfrow=c(2, 3))
print_mblankets(bl.alarm)
par(mfrow=c(1, 1))

## ------------------------------------------------------------------------
# Equivalence class. 
cpdag.alarm <- cpdag(bl.alarm)
plot(cpdag.alarm)

## ------------------------------------------------------------------------
library(gRain) 
?gRain
gr.alarm <- as.grain(bl.alarm.fit)

## ------------------------------------------------------------------------
yn <- c("yes","no")
B  <- cptable(~Burglar, values=c(30,70),levels=yn)
E  <- cptable(~Earthquake, values=c(35,65),levels=yn)
A  <- cptable(~Alarm+Earthquake+Burglar, values=c(95,5,90,10,60,40,1,99),levels=yn)
W  <- cptable(~Watson+Alarm, values=c(80,20,40,60),levels=yn)
N  <- cptable(~News+Earthquake, values=c(60,40,1,99), levels=yn)

## ------------------------------------------------------------------------
cptlist <- compileCPT(list(B, E, A, W, N))
gr.alarm.orig <- grain(cptlist)

## ---- echo=TRUE, eval = FALSE, results = "hide"--------------------------
## plot(gr.alarm.orig)

## ------------------------------------------------------------------------
gr.alarm.orig$cptlist$Earthquake

## ---- echo = TRUE, results = "hide"--------------------------------------
bn <- gr.alarm.orig$cptlist$Burglar['no']
en <- gr.alarm.orig$cptlist$Earthquake['no']
an <- gr.alarm.orig$cptlist$Alarm['no', 'no', 'no']
nn <- gr.alarm.orig$cptlist$News['no', 'no']
wn <- gr.alarm.orig$cptlist$Watson['no', 'no']
bn * en * an * nn * wn 

## ------------------------------------------------------------------------
gr.alarm <- compile(gr.alarm.orig) # Compile first
gr.alarm

## ------------------------------------------------------------------------
querygrain(object=gr.alarm, nodes="Earthquake")
querygrain(object=gr.alarm, nodes="Burglar") 

## ---- eval = FALSE-------------------------------------------------------
## no <- rep("no", 5)
## nodes <- c('Burglar', 'Earthquake', 'Alarm', 'Watson', 'News')
## gr.alarm <- setEvidence(object=gr.alarm, nodes=, states=)
## pEvidence(gr.alarm)

## ---- echo = FALSE, results = "hide"-------------------------------------
no <- rep("no", 5)
nodes <- c('Burglar', 'Earthquake', 'Alarm', 'Watson', 'News')
gr.alarm <- setEvidence(object=gr.alarm, nodes=nodes, states=no)
pEvidence(gr.alarm)

## ------------------------------------------------------------------------
gr.alarm
gr.alarm <- retractEvidence(gr.alarm, nodes)
gr.alarm

## ------------------------------------------------------------------------
gr.alarm <- setEvidence(object=gr.alarm, nodes="Earthquake", states="yes")

## ---- eval = FALSE-------------------------------------------------------
## q.wnb <- querygrain(gr.alarm, type = "joint", nodes = )
## q.wnb

## ---- echo = FALSE-------------------------------------------------------
q.wnb <- querygrain(gr.alarm, type = "joint", nodes = c("Watson", "News", "Burglar"))
q.wnb

## ---- echo=TRUE, fig.keep = "none"---------------------------------------
map(q.wnb)
q.wnb["yes", "yes", "no"]


## ----child = 'c01-inference.rmd'-----------------------------------------

## ---- results='hide', echo=FALSE, include=TRUE, error=FALSE, warning=FALSE, message=FALSE----
library(bnlearn)
library(gRain)
library(graph)
source('functions.R')

## ------------------------------------------------------------------------
asia.fit <- load_asia_fit()

## ------------------------------------------------------------------------
asia.fit$either

## ------------------------------------------------------------------------
asia.gr <- as.grain(asia.fit)
m <- moralize(asia.gr$dag)
t <- triangulate(m)

## ---- eval = FALSE-------------------------------------------------------
## library(gRbase)
## getCliques()

## ------------------------------------------------------------------------
asia.gr <- compile(asia.gr)
# origpot contains the clique potentials, i.e., initial cliques  
asia.gr$origpot[[1]] 
asia.fit$tub$prob
asia.fit$asia$prob

## ---- eval = FALSE, results = 'hide'-------------------------------------
## asia.gr$rip

## ------------------------------------------------------------------------
asia.gr <- propagate(asia.gr)

## ---- eval = FALSE-------------------------------------------------------
## asia.gr$equipot[[1]] == asia.gr$origpot[[1]]

## ---- eval = FALSE-------------------------------------------------------
## # equipot contains the clique marginals
## asia.gr$equipot[[5]]
## apply(asia.gr$equipot[[5]], 2, sum)
## apply(asia.gr$equipot[[4]], , )

## ---- eval = FALSE-------------------------------------------------------
## querygrain(asia.gr, nodes = 'bronc')

## ------------------------------------------------------------------------
summary(asia.gr)
asia.gr <- setEvidence(asia.gr, nodes = 'tub', states = 'yes', propagate = FALSE)
asia.gr <- propagate(asia.gr)
summary(asia.gr)  

## ---- eval = FALSE-------------------------------------------------------
## querygrain(asia.gr, nodes = c('lung', 'either'), type = 'joint')
## apply(asia.gr$equipot[[]], c(2, 3), )

## ------------------------------------------------------------------------
yn <- c("yes", "no")
set.seed(0)
s <- sample(yn, 1, prob = asia.fit$smoke$prob)

## ------------------------------------------------------------------------
set.seed(0)
# evidence = TRUE means that we are not conditioning on any evidence
samples.asia <- cpdist(asia.fit, nodes = nodes(asia.fit), 
                       evidence = TRUE, n = 15)
summary(samples.asia)

## ------------------------------------------------------------------------
t <- table(samples.asia[, c('smoke', 'dysp')])
prop.table(t)

## ------------------------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = TRUE, n = 15)
ep			  

## ---- results = 'hide'---------------------------------------------------
gr.asia <- as.grain(asia.fit)
q <- querygrain(gr.asia, nodes = c("smoke", "dysp"), type = "joint")
q

## ---- eval = FALSE-------------------------------------------------------
## set.seed(0)
## ep <- cpquery(asia.fit,  )

## ------------------------------------------------------------------------
set.seed(0)
samples.asia <- cpdist(asia.fit, nodes = c("smoke", "dysp"), 
                       evidence=(asia == "yes"), 
                       n=5000)

## ---- echo = FALSE, results = "hide"-------------------------------------
nrow(samples.asia)

## ---- eval = FALSE-------------------------------------------------------
## ep <- prop.table(table(samples.asia))
## ep <- ep['no', 'yes']
## gray <- setEvidence(gr.asia, nodes = "asia", states = c("yes"))
## q <- querygrain(gray, nodes = c("smoke", "dysp"), type = "joint")
## tp <- q['no', 'yes']
## abs(ep - tp)

## ---- echo = FALSE, results = "hide"-------------------------------------
set.seed(0)
samples.asia <- cpdist(asia.fit, nodes = c("smoke", "dysp"), 
                       evidence=(asia == "yes"), 
                       n=3000000)
nrow(samples.asia)
ep <- prop.table(table(samples.asia))['no', 'yes']
abs(ep - tp)

## ------------------------------------------------------------------------
set.seed(0)
samples.asia <- cpdist(asia.fit, nodes = nodes(asia.fit),
                       evidence=list(asia = "yes"), 
                       n=5000, method = "lw")

## ---- echo = TRUE, results = "hide"--------------------------------------
w <- attr(samples.asia, 'weights')
summary(w)

## ---- eval = FALSE, echo=TRUE, results="hide", fig.keep = "none"---------
## set.seed(0)
## samples.asia <- cpdist(, nodes = ,
##                        evidence=list(lung = 'yes'),
##                        n=5000, method = "lw")
## w <- attr(samples.asia, 'weights')

## ---- eval = TRUE, echo=FALSE, results="hide", fig.keep = "none"---------
set.seed(0)
samples.asia <- cpdist(asia.fit, nodes = c("smoke", "dysp"),
                       evidence=list(lung = 'yes'),
                       n=5000, method = "lw")    
w <- attr(samples.asia, 'weights')

## ---- eval = FALSE-------------------------------------------------------
## prop.table(table(samples.asia$smoke))
## asia.fit$

## ---- echo = FALSE, results='hide'---------------------------------------
prop.table(table(samples.asia$smoke))
asia.fit$smoke

## ---- eval = FALSE, echo=FALSE, results="hide", fig.keep = "none"--------
## head(samples.asia)
## head(w)

## ---- eval = FALSE, echo = FALSE-----------------------------------------
## asia.fit$lung$prob['yes', 'no'] / asia.fit$lung$prob['yes', 'yes']

## ---- eval = FALSE, echo=TRUE--------------------------------------------
## prop.table(xtabs(w ~ smoke + dysp, data = cbind(samples.asia, w = w)))

## ---- eval = FALSE, echo=TRUE, results="hide", fig.keep = "none"---------
## set.seed(0)
## epl <- cpquery(,  event = (smoke == "no" & dysp == ),
##               evidence = list(lung = 'yes'), n = 5000, method = 'lw')
## epl

## ---- eval = TRUE, echo=FALSE, results="hide", fig.keep = "none"---------
set.seed(0)
epl <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = list(lung = 'yes'), n = 5000, method = 'lw')
epl 

## ---- echo = FALSE-------------------------------------------------------
gr.asia <- setEvidence(gr.asia, nodes = 'lung', states = 'yes')
q <- querygrain(gr.asia, nodes = c("smoke", "dysp"), type = "joint")
tpl <- q['no', 'yes']
abs(tpl - epl)
tpl / epl

## ---- eval = FALSE, results = 'hide'-------------------------------------
## gr.asia <- setEvidence(gr.asia, nodes = 'lung', states = 'yes')
## q <- querygrain(gr.asia, nodes = c("smoke", "dysp"), type = "joint")
## tpl <- q['no', 'yes']
## abs(tpl - )

## ---- eval = TRUE--------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = list(asia = 'yes'), n = 100, method = 'lw')  
abs(ep - tp)
abs(tp / ep)

## ------------------------------------------------------------------------
sum(w)

## ---- eval = TRUE, echo=TRUE, results="hide", fig.keep = "none"----------
gr.asia <- as.grain(asia.fit)
q <- querygrain(gr.asia, nodes = c("smoke", "lung"), type = "joint")
psl <- q['yes', 'yes'] / (q['yes', 'yes'] + q['yes', 'no'])
sum(w / psl)

## ------------------------------------------------------------------------
set.seed(0)
ep <- cpquery(asia.fit,  event = (smoke == "no" & dysp == "yes"), 
              evidence = list(lung = 'yes'), n = 5000, method = 'lw')
abs(ep  - tpl)

## ---- eval = FALSE, echo = FALSE-----------------------------------------
## mutilated.asia <- mutilated(asia.fit, evidence=list(lung = 'yes', bronc = 'yes'))
## u <- as.bn(as.grain(mutilated.asia))
## plot(u)
## mutilated.asia$lung

## ------------------------------------------------------------------------
summary(marks)

## ------------------------------------------------------------------------
bn.marks <- hc(marks)
plot(bn.marks)
bn.marks 

## ---- eval = FALSE-------------------------------------------------------
## bn.marks.fit <- bn.fit(bn.marks, marks)
## cpquery(bn.marks.fit, event = , evidence = )

## ------------------------------------------------------------------------
bn.marks.fit <- bn.fit(bn.marks, marks) 
cpquery(bn.marks.fit, event = ((ALG < 60) & (MECH >= 60)), evidence = TRUE)      
cpquery(bn.marks.fit, event = ((STAT >= 60) & (MECH >= 60)), evidence = TRUE)      
cpquery(bn.marks.fit, event = ((STAT >= 60) & (MECH >= 60)), evidence = (ALG >= 60))      

## ------------------------------------------------------------------------
library(ggplot2)
samples.marks <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), evidence = (ALG < 60))      
ggplot(samples.marks, aes(x = STAT, y = MECH)) + geom_bin2d()
cor(samples.marks$STAT, samples.marks$MECH)
cor(marks$STAT, marks$MECH) 

## ---- echo = TRUE--------------------------------------------------------
cpquery(bn.marks.fit, event = ((STAT >= 60)), evidence = ((MECH >= 60) & ALG >= 60))      
cpquery(bn.marks.fit, event = ((STAT >= 60)), evidence = (ALG >= 60))

## ------------------------------------------------------------------------
samples.marks <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), evidence = (ALG < 60))      
samples.marks.noevidence <- cpdist(bn.marks.fit, nodes = c('STAT', 'MECH'), evidence = TRUE)      
nrow(samples.marks )
nrow(samples.marks.noevidence) 

## ---- error = TRUE-------------------------------------------------------
cpquery(bn.marks.fit, event = ((STAT >= 60)), evidence = (ALG >= 60))


## ----child = 'c01-learning.rmd'------------------------------------------

## ------------------------------------------------------------------------
library(bnlearn)

## ------------------------------------------------------------------------
breast <- foreign::read.arff('data/dbreast-cancer.arff')
summary(breast)

## ------------------------------------------------------------------------
anyNA(breast)

## ------------------------------------------------------------------------
hc.breast <- hc(breast, score = "bic")
plot(hc.breast)

## ---- echo = FALSE, results = "hide"-------------------------------------
dsep(hc.breast, x = 'menopause', y = 'Class')

## ---- echo = FALSE, results = "hide"-------------------------------------
mb(hc.breast, node = "Class")

## ------------------------------------------------------------------------
score(hc.breast, breast, type="loglik")

## ---- echo = FALSE, results = "hide"-------------------------------------
score(hc.breast, breast, type="bic", debug = TRUE)
score(hc.breast, breast, type="k2", debug = TRUE)

## ---- eval = FALSE-------------------------------------------------------
## eq_dag <-
## score(eq_dag, breast, type="bic")
## score(eq_dag, breast, type="bde")
## score(eq_dag, breast, type="k2")

## ---- echo = FALSE, results = FALSE--------------------------------------
rev.hc.breast <- reverse.arc(hc.breast, from='age', 'menopause')
score(rev.hc.breast, breast, type="bic")
score(rev.hc.breast, breast, type="bde")
score(rev.hc.breast, breast, type="k2")

## ---- eval = FALSE-------------------------------------------------------
## pcdag <- skeleton()
## plot(pcdag )

## ---- echo = FALSE, results = FALSE--------------------------------------
pcdag <- skeleton(hc.breast)
plot(pcdag )

## ---- echo = FALSE, results = "hide"-------------------------------------
loglik.hc.breast <- hc(breast, score='loglik')
nparams(loglik.hc.breast, breast)

## ---- eval = FALSE-------------------------------------------------------
## loglik.hc.breast <- hc(breast, score='loglik')
## nparams(loglik.hc.breast, breast)

## ------------------------------------------------------------------------
hc.breast 

## ---- echo = FALSE-------------------------------------------------------
bde.hc.breast <- hc(breast, score='bde')
plot(bde.hc.breast)

## ---- echo = FALSE, results = "hide"-------------------------------------
nparams(bde.hc.breast, breast)
nparams(hc.breast, breast)

## ---- eval = FALSE-------------------------------------------------------
## compare(hc.breast, bde.hc.breast, arcs = TRUE)

## ---- echo = FALSE, fig.keep='none'--------------------------------------
hc.steps <- lapply(1:3, function(i) hc(breast, max.iter = i))
plot(hc.steps[[1]])
plot(hc.steps[[2]])
plot(hc.steps[[3]])

## ---- echo = FALSE-------------------------------------------------------
sapply(hc.steps, score, breast, type="bic")

## ---- eval = FALSE, echo = FALSE, fig.keep= 'none'-----------------------
## plot_search_progress(breast)

## ------------------------------------------------------------------------
set.seed(100)
hc.breast.restart <- hc(breast, restart = 1000, perturb = 10)
BIC(hc.breast.restart, breast)
all.equal(cpdag(hc.breast.restart), cpdag(hc.breast))

## ------------------------------------------------------------------------
gs.breast <- gs(x = breast)

## ------------------------------------------------------------------------
plot(gs.breast)  

## ---- eval = FALSE-------------------------------------------------------
## score(gs.breast, breast, type = "loglik")

## ------------------------------------------------------------------------
gs.breast <- cextend(gs.breast)
score(gs.breast, breast)

## ---- echo = FALSE, results = FALSE--------------------------------------
compare(hc.breast, gs.breast, arcs = TRUE)

## ------------------------------------------------------------------------
shd(gs.breast, hc.breast)
hamming(gs.breast, hc.breast)
compare(skeleton(hc.breast), skeleton(gs.breast), arcs = TRUE) 

## ---- echo = FALSE, results = FALSE--------------------------------------
score(gs.breast, breast)
score(hc.breast, breast)

score(gs.breast, breast, type = 'loglik')
score(hc.breast, breast, type = 'loglik')

nparams(gs.breast, breast)
nparams(hc.breast, breast)

## ------------------------------------------------------------------------
gs.breast

## ---- eval = FALSE-------------------------------------------------------
## gs.breast.string <- gs(breast, alpha=)
## narcs(gs.breast.string)

## ---- echo = FALSE, results = FALSE--------------------------------------
gs.breast.string <- gs(breast, alpha=0.01)
narcs(gs.breast.string)

## ---- eval = FALSE-------------------------------------------------------
## gs.breast.2 <- gs(breast, test = )
## gs.breast.2 <- cextend(gs.breast.2)
## plot(gs.breast.2)

## ---- eval = FALSE, echo=FALSE, results="hide", fig.keep = "none"--------
## gs.breast.2 <- gs(breast, test = 'mi-sh')
## gs.breast.2 <- cextend(gs.breast.2)
## plot(gs.breast.2)

## ---- results = 'hide'---------------------------------------------------
gr.breast <- gs(breast, debug = TRUE)

## ---- echo = FALSE, results = 'hide'-------------------------------------
hiton.breast <- si.hiton.pc(breast)
hamming(hiton.breast, gs.breast)

## ---- results = 'hide', error=FALSE, warning=FALSE, message=FALSE--------
bn.cv(breast, 'iamb', loss = "logl")
bn.cv(breast, 'hc', loss = "logl")

## ------------------------------------------------------------------------
data("clgaussian.test")
head(clgaussian.test)  

## ------------------------------------------------------------------------
plot(hc(clgaussian.test))

## ---- out.width='4cm'----------------------------------------------------
data("marks")
latent <- factor(c(rep("A", 44), "B", rep("A", 7), rep("B", 36)))
plot(hc(marks[latent == "A", ]))
plot(hc(marks[latent == "B", ]))
plot(hc(marks))

## ------------------------------------------------------------------------
dmarks = discretize(marks, breaks = 2, method = "interval")
plot(hc(data.frame(dmarks, LAT = latent)))

## ------------------------------------------------------------------------
lmarks <- data.frame(marks, LAT = latent)
plot(hc(lmarks))

## ------------------------------------------------------------------------
breast.bn.fit <- bn.fit(hc.breast, breast)
bn.fit.barchart(breast.bn.fit$tumor_size) 

## ---- results='hide', echo=FALSE, include=TRUE, error=FALSE, warning=FALSE, message=FALSE----
library(gRain)

## ------------------------------------------------------------------------
graph.breast <- as.graphNEL(hc.breast)
gr.breast <- grain(graph.breast, data = breast, smooth = 0)
gr.breast$cptlist$menopause

## ------------------------------------------------------------------------
gr.breast.bpe <- grain(graph.breast, data = breast, smooth = 1)
gr.breast.bpe$cptlist$menopause

## ---- results = 'hide'---------------------------------------------------
logLik(as.bn.fit(gr.breast.bpe), breast)
logLik(as.bn.fit(gr.breast), breast)

## ---- echo = FALSE, results = FALSE--------------------------------------
iss <- 100 * nrow(breast)
gr.breast.bpe <- grain(graph.breast, data = breast, smooth = iss)
gr.breast.bpe$cptlist$menopause

## ---- echo = FALSE, results= "hide"--------------------------------------
# TODO: FIX
# hc.breast.fit <- bn.fit(hc.breast, breast)
# hc.breast.fit$Class

## ------------------------------------------------------------------------
data(marks)
bn.marks <- hc(marks)
bn.marks <- bn.fit(bn.marks, marks)

## ------------------------------------------------------------------------
coefficients(bn.marks)  
sigma(bn.marks$MECH)   
sigma(bn.marks$VECT)   
bn.fit.qqplot(bn.marks)

## ------------------------------------------------------------------------
m <- as.matrix(marks)
# You will need the glmnet package for this
library(glmnet)
gnet <- glmnet(m[ , c('VECT', 'MECH')], m[, 'ALG'], alpha =0, family = "gaussian")
coefs <- coef(gnet, s = 0.1)[, 1]
bn.marks$ALG = list(coef = coefs, sd = sigma(bn.marks$ALG)) 


## ----child = 'c01-classify.rmd'------------------------------------------

## ------------------------------------------------------------------------
load('data/car.rda')
summary(car)

## ------------------------------------------------------------------------
library(bnclassify)

## ---- eval = FALSE-------------------------------------------------------
## nb.car <- nb(class = 'class', dataset =  )

## ------------------------------------------------------------------------
nb.car <- lp(nb.car, car, smooth = 0) 
params(nb.car)[['class']]

## ------------------------------------------------------------------------
car[1, -7]

## ---- eval = FALSE-------------------------------------------------------
## b <- params(nb.car)[['buying']]['vhigh', ]
## m <- params(nb.car)[['maint']]['vhigh', ]
## d <- params(nb.car)[['doors']]['2', ]
## p <- params(nb.car)[['persons']]['2', ]
## l <- params(nb.car)[['lug_boot']]['', ]
## s <- params(nb.car)[['safety']]['', ]
## cp <- params(nb.car)[['class']]
## cpost <- cp * b * m *  * p *  *

## ---- eval = FALSE-------------------------------------------------------
## nb.car <-

## ------------------------------------------------------------------------
p <- predict(nb.car, car, prob = TRUE)
tail(p)

## ---- results = 'hide'---------------------------------------------------
p <- predict(nb.car, car)
tail(p)

## ------------------------------------------------------------------------
cm <- table(predicted=p, true=car$class)
cm
sum(cm * diag(1, nrow(cm), ncol(cm))) / sum(cm)

## ------------------------------------------------------------------------
bnclassify:::accuracy(p, car$class)

## ---- eval = FALSE-------------------------------------------------------
## ci.test(...)

## ---- results = 'hide'---------------------------------------------------
car_wo_doors <- car[, -3]
nb.car.wod <- bnc('nb', 'class', dataset = car, smooth = 1)
p <- predict(nb.car.wod, car )
p <- predict(nb.car, car )
bnclassify::accuracy(p, car$class) 

## ---- eval = FALSE-------------------------------------------------------
## ci.test('maint', 'buying', 'class', car)

## ---- eval = FALSE-------------------------------------------------------
## car2 <- cbind(car, safety2=car$safety)
## nb.car2 <- bnc('nb', 'class', car2, smooth = 1)
## p <- predict(nb.car2, car2)
## bnclassify:::accuracy(p, car2$class)

## ---- eval = FALSE-------------------------------------------------------
## sft <- car[, rep(6,10)]
## colnames(sft) <- paste0('safety', 1:10)
## car2 <- cbind(car, sft)
## nb.car2 <- bnc('nb', 'class', car2, smooth = 1)
## p <- predict(nb.car2, car2)
## bnclassify:::accuracy(p, car2$class)

## ------------------------------------------------------------------------
tn <- tan_cl('class', car)
tn <- lp(tn, car, smooth = 1)
plot(tn)

## ------------------------------------------------------------------------
tns <- tan_cl('class', car, root = 'safety')
plot(tns)
tns <- lp(tns, car, smooth = 1)
p <- predict(tn, car, prob = TRUE)
ps <- predict(tns, car, prob = TRUE)
identical(p, ps)

## ---- results = 'hide'---------------------------------------------------
p <- predict(tn, car )
bnclassify::accuracy(p, car$class) 

## ---- eval = FALSE-------------------------------------------------------
## nparams(...)
## nparams(...)
## logLik(, car)
## logLik(, car)

## ------------------------------------------------------------------------
p <- predict(tn, car )
n <- predict(nb.car, car )
ind_error <- which(p != car$class & n != car$class)
car$class[ind_error]
p[ind_error]
n[ind_error]
p <- predict(tn, car, prob = TRUE )
n <- predict(nb.car, car, prob = TRUE )
# head(p[ind_error, ])
# head(n[ind_error, ])
maxp <- apply(p[ind_error, ], 1, max)
maxn <- apply(n[ind_error, ], 1, max)
plot(maxn, maxp, ylim  = c(0, 1), xlim = c(0, 1))

## ------------------------------------------------------------------------
tn.aic <- tan_cl('class', car, score = 'aic')
tn.aic <- lp(tn.aic, car, smooth = 1)
plot(tn.aic)

## ------------------------------------------------------------------------
AIC(object = tn, car)
AIC(object = tn.aic, car)

## ---- eval = FALSE-------------------------------------------------------
## sl.cmi <- bnclassify:::cmi(, , car, 'class')
## # The number of parameters added is:
## ap <- (3 - 1) * (3 - 1) * 4
## N <-
## N * sl.cmi - ap

## ---- results="hide"-----------------------------------------------------
bnclassify:::local_ode_score_contrib('safety', 'lug_boot', 'class', car)

## ------------------------------------------------------------------------
tn.bic <- tan_cl('class', car, score = 'bic')
plot(tn.bic)

## ---- eval = FALSE, results = "hide"-------------------------------------
## tn.bic <- ...
## bnclassify::cv(list(nb.car, tn, tn.aic, tn.bic),  car, k = 10)

## ------------------------------------------------------------------------
set.seed(0)
tn.hc <- tan_hc('class', car, k = 10, epsilon = 0, smooth = 1)

## ------------------------------------------------------------------------
tn.hc$.greedy_scores_log

## ---- eval = FALSE-------------------------------------------------------
## set.seed(0)
## tn.hc2 <- tan_hc('class', car, k = 10, epsilon = , smooth = 1)

## ---- echo = FALSE, results = "hide"-------------------------------------
set.seed(0)
tn.hc2 <- tan_hc('class', car, k = 10, epsilon = , smooth = 1)
plot(tn.hc2)

## ------------------------------------------------------------------------
tn.hc2$.greedy_scores_log

## ------------------------------------------------------------------------
 system.time(tan_hc('class', car, k = 10, epsilon = 0, smooth = 1))
 system.time(tan_cl('class', car))

## ---- echo = FALSE, results = "hide"-------------------------------------
system.time(tan_hc('class', car, k = 2, epsilon = 0, smooth = 1)) 

## ---- cache = FALSE, eval = FALSE, echo = FALSE--------------------------
## cv(list(tn.hcsp, tn.hc), car, k = 10, dag = TRUE, smooth = 1)

## ---- cache = FALSE------------------------------------------------------
set.seed(0)
bs.car <- bsej('class', car, k = 10, epsilon = 0, smooth = 1)

## ---- echo = FALSE, results = "hide"-------------------------------------
plot(bs.car)
bs.car

## ---- results = "hide"---------------------------------------------------
bnclassify:::is_supernode(c('maint', 'buying'), bs.car)

## ---- echo = FALSE, results = "hide", cache = FALSE----------------------
set.seed(0)
fs.car <- fssj('class', car, k = 10, epsilon = 0, smooth = 1)

## ---- eval = FALSE-------------------------------------------------------
## set.seed(0)
## fs.car <- fssj()

## ---- echo = FALSE, results = "hide"-------------------------------------
plot(fs.car)
fs.car

## ------------------------------------------------------------------------
ia.car <- iamb(car)
plot(ia.car)

## ------------------------------------------------------------------------
mb.class <- mb(ia.car, 'class')
mb.car <- bnlearn::subgraph(ia.car, c(mb.class, 'class'))
mb.car <- bn.fit(mb.car, car[, nodes(mb.car)])
mb.grain <- as.grain(mb.car)

## ------------------------------------------------------------------------
p <- gRain::predict.grain(mb.grain,  'class', newdata  = car)
fp <- factor(p$pred$class, levels = levels(car$class))
bnclassify:::accuracy(fp, car$class)


## ----child = 'c01-alarm.rmd'---------------------------------------------

## ------------------------------------------------------------------------
load('data/alarm.rda')
alarm.fit <- bn
bn <- as.bn(as.grain(alarm.fit)) 
plot(as.grain(alarm.fit))

## ---- echo = FALSE, error=FALSE, warning=FALSE, message=FALSE, results='hide'----
sample <- cpdist(alarm.fit, nodes = nodes(bn), evidence = TRUE)
ls <- iamb(sample)
ls <- cextend(ls)
bnlearn::narcs(ls)
bnlearn::nparams(ls, sample)
logLik(ls, sample)
logLik(alarm.fit, sample)
shd(bn, ls)
compare(bn, ls)


