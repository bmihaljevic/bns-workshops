test_install <- function() {
	d <- gRbase::dag(~Burglar, ~Earthquake, ~Alarm:Earthquake:Burglar, ~Watson:Alarm, ~News:Earthquake)
	graph::plot(d)
	nrarcs <- narcs(as.bn(d))
    stopifnot(nrarcs == 4)
    print("Installed OK")
}
nfree_params <- function(x) {  
  stopifnot(inherits(x, "grain"))
  params <- sapply(x$cptlist, function(x) {
    d <- dim(x)
    if (length(d) == 1) (d - 1)
    else (d[1] - 1) * prod(d[-1]) 
  })
  sum(params)
}
plot.bn <- function(x, ...) {
  graphviz.plot(x, ...)  
}
map <- function(joint) {
  stopifnot(!is.null(dim(joint)))
  ind_max <- which(sapply(joint, function(v) isTRUE(all.equal(max(joint), v))))
  if (length(ind_max) > 1) {
    warning("More than one MAP. Chosing one randomly.")
    oind_max <- ind_max
    ind_max <- sample(ind_max, size = 1)
    stopifnot(ind_max %in% oind_max)
  }
  ind <- arrayInd(ind_max, .dim = dim(joint))
  state <- mapply('[', dimnames(joint), ind)
  prob <- joint[ind_max]
  list(state=state, prob=prob)
}
print_mblankets <- function(bn) {
  lapply(nodes(bn), function(node) {
    mb.node <- mb(x=bn, node=node)
    mbe <- subgraph(bn, nodes = mb.node)
    plot(mbe, main=node)
  })  
}
plot_search_progress <- function(dataset) {
  for (i in 1:1000) {
    bn <- hc(dataset, max.iter = i)
    plot(bn)
    n <- readline("continue (y/n)? ")
    py <- grep("y",n)
    if (!length(py) || py != 1) break
  }
}
load_asia <- function() {
  load('data/asia.rda')
  bn.net(bn)  
}
load_asia_fit <- function() {
  load('data/asia.rda')
  gr.asia <- as.grain(bn)
  as.bn.fit(gr.asia)  
}
plot_moral_triang_step <- function(bn) {
  par(mfrow=c(1, 3))
  plot(bn)
  m <- moralize(bn$dag)
  plot(m) 
  t <- triangulate(m)
  plot(t) 
  par(mfrow=c(1, 1))
}
plot_particle_estimates <- function(prob, nparticles, tp, epsilon) { 
   colnames(prob) <- nparticles
   prob <- as.data.frame(prob)
   prob <- tidyr::gather(prob, key = 'particles')
   prob$particles <-  as.numeric(prob$particles)
   ggplot2::ggplot(prob, ggplot2::aes(x = particles, y = value)) + ggplot2::geom_point()  +
   ggplot2::geom_hline(yintercept = tp, color = 'red') + 
   ggplot2::geom_hline(yintercept = tp + epsilon,  linetype="dashed", color = 'blue') + 
   ggplot2::geom_hline(yintercept = tp - epsilon,  linetype="dashed",  color = 'blue')  
}