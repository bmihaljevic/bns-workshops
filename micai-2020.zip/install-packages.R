install.packages('bnlearn')
install.packages('bnclassify') 
# install.packages('usethis')  
install_bioc_old <- function() {
  source("http://bioconductor.org/biocLite.R")
  biocLite(c("graph", "RBGL", "Rgraphviz"), suppressUpdates = TRUE) 
} 
install_bioc_new <- function() {
  if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")
  BiocManager::install(pkgs = c("graph", "RBGL", "Rgraphviz"), update = FALSE)
}      
tryCatch(install_bioc_old(), error = function(e) install_bioc_new()  )
install.packages('gRain')
install.packages('glmnet')
install.packages('ggplot2') 
install.packages('BayesianNetwork')
# recommended packages
# install.packages('foreign')
# install.packages('parallel')